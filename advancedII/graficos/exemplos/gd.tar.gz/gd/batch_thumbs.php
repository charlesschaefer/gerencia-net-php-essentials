<?php
$dir = new DirectoryIterator('./img');
while ($dir->valid()) {

	if ($dir->get)

	$dir->next(); // IMPORTANTÍSSIMO. Não esquecer jamais :)
}
?>
